// BACKEND: Node.js Express server for feedback classification

const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// BACKEND: Classification logic using keyword-based approach
class FeedbackClassifier {
    constructor() {
        // Define keywords for each category
        this.categories = {
            'Academics': {
                keywords: [
                    'professor', 'teacher', 'lecture', 'course', 'curriculum', 'syllabus',
                    'assignment', 'homework', 'exam', 'test', 'grade', 'grading',
                    'class', 'classroom', 'teaching', 'learn', 'study', 'subject',
                    'textbook', 'material', 'lab', 'laboratory', 'practical',
                    'semester', 'academic', 'education', 'knowledge', 'skill'
                ],
                examples: [
                    'The professor explains concepts very clearly',
                    'Course material is outdated and needs revision',
                    'Assignments are too difficult for the level'
                ]
            },
            'Facilities': {
                keywords: [
                    'building', 'infrastructure', 'facility', 'equipment', 'room',
                    'library', 'cafeteria', 'canteen', 'food', 'hostel', 'dormitory',
                    'gym', 'sports', 'playground', 'wifi', 'internet', 'computer',
                    'lab', 'laboratory', 'toilet', 'washroom', 'parking',
                    'maintenance', 'clean', 'dirty', 'repair', 'broken'
                ],
                examples: [
                    'The library needs more study spaces',
                    'Cafeteria food quality has improved',
                    'WiFi connection is very slow in dormitories'
                ]
            },
            'Administration': {
                keywords: [
                    'office', 'staff', 'service', 'admission', 'registration',
                    'fee', 'payment', 'document', 'certificate', 'process',
                    'procedure', 'policy', 'rule', 'regulation', 'administration',
                    'management', 'support', 'help', 'assistance', 'communication',
                    'information', 'notice', 'announcement', 'schedule'
                ],
                examples: [
                    'Fee payment process is very complicated',
                    'Administrative staff is very helpful',
                    'Registration procedure needs to be simplified'
                ]
            },
            'General': {
                keywords: [
                    'overall', 'experience', 'college', 'university', 'campus',
                    'environment', 'culture', 'student', 'life', 'activity',
                    'event', 'club', 'society', 'placement', 'career', 'job',
                    'future', 'recommend', 'suggestion', 'improve', 'better',
                    'good', 'bad', 'excellent', 'poor', 'satisfied', 'happy'
                ],
                examples: [
                    'Overall college experience has been great',
                    'Campus environment is very friendly',
                    'More extracurricular activities should be organized'
                ]
            }
        };
    }

    classify(feedbackText) {
        const text = feedbackText.toLowerCase();
        const scores = {};
        
        // Calculate scores for each category
        for (const [category, data] of Object.entries(this.categories)) {
            scores[category] = 0;
            
            // Count keyword matches
            for (const keyword of data.keywords) {
                if (text.includes(keyword.toLowerCase())) {
                    scores[category]++;
                }
            }
        }
        
        // Find category with highest score
        let bestCategory = 'General';
        let maxScore = scores['General'];
        
        for (const [category, score] of Object.entries(scores)) {
            if (score > maxScore) {
                maxScore = score;
                bestCategory = category;
            }
        }
        
        // Generate explanation
        const explanation = this.generateExplanation(bestCategory, feedbackText);
        
        return {
            category: bestCategory,
            confidence: maxScore,
            explanation: explanation
        };
    }
    
    generateExplanation(category, feedbackText) {
        const explanations = {
            'Academics': 'This feedback relates to teaching, learning, courses, or educational content.',
            'Facilities': 'This feedback concerns physical infrastructure, equipment, or campus facilities.',
            'Administration': 'This feedback is about administrative processes, staff services, or institutional procedures.',
            'General': 'This feedback provides general comments about the overall college experience.'
        };
        
        return explanations[category];
    }
}

// Initialize classifier
const classifier = new FeedbackClassifier();

// BACKEND: API endpoint for feedback classification
app.post('/api/classify', (req, res) => {
    try {
        const { studentName, department, feedbackText } = req.body;
        
        // Validate input
        if (!feedbackText || !department) {
            return res.status(400).json({
                error: 'Feedback text and department are required'
            });
        }
        
        // Classify the feedback
        const classification = classifier.classify(feedbackText);
        
        // Prepare response
        const result = {
            studentName: studentName || 'Anonymous',
            department: department,
            feedbackText: feedbackText,
            category: classification.category,
            confidence: classification.confidence,
            explanation: classification.explanation,
            timestamp: new Date().toISOString()
        };
        
        // Log the classification (in a real app, you'd save to database)
        console.log('Feedback classified:', result);
        
        res.json(result);
        
    } catch (error) {
        console.error('Classification error:', error);
        res.status(500).json({
            error: 'Internal server error during classification'
        });
    }
});

// BACKEND: API endpoint to get category statistics (for future use)
app.get('/api/stats', (req, res) => {
    // In a real application, this would query a database
    res.json({
        message: 'Statistics endpoint - would show feedback distribution by category',
        categories: Object.keys(classifier.categories)
    });
});

// Serve the main HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Start server
app.listen(PORT, () => {
    console.log(`College Feedback Classifier server running on port ${PORT}`);
    console.log(`Open http://localhost:${PORT} to view the application`);
});

module.exports = app;